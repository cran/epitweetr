package org.ecdc.epitweetr.test

import org.scalatest._

class UnitTest()  extends FlatSpec {
  def getSpark = SharedSpark.getSpark
}

